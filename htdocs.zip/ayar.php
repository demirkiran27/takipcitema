<?php 
$siteBaslik = "Deneme";
$siteLinki = "https://sites.com";
$siteinstagramLink = "https://sites.com/instagram";
$sitefacebookLink = "https://sites.com/facebook";
$sitetiktokLink = "https://sites.com/tiktok";
$siteyoutubeLink = "https://sites.com/youtube";
$sitetwitterLink = "https://sites.com/twitter";
?>
<!--
	ayarları buradan değiştirebilirisiniz. r10/demirkiran
-->
